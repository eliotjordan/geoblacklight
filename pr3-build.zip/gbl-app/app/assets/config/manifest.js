//= link_tree ../images
//= link_directory ../stylesheets .css

//= link application.js
//= link_tree ../../javascript .js
//= link_tree ../../../vendor/javascript .js
