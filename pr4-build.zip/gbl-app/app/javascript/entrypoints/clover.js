import { CloverInitializer } from '@geoblacklight/frontend'

document.addEventListener('DOMContentLoaded', () => {
  new CloverInitializer().run()
})
