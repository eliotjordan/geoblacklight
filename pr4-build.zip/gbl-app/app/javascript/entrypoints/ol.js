import '@geoblacklight/frontend/dist/style.css'
import { OlInitializer } from '@geoblacklight/frontend'

document.addEventListener('DOMContentLoaded', () => {
  new OlInitializer().run()
})
